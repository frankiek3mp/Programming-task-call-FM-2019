package TaskTwitter2019;

import java.io.FileReader; 
import java.util.Iterator;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.Map; 
import org.json.simple.JSONArray; 
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.util.List;
import java.util.ArrayList;
import java.io.*;



class Info{
	String nome_user;
	int count_tweet;
	int count_user_mentions;
    long id;
    String screen_name;
}


public class ParsingTweet {
public static void main(String[] args) throws Exception{ 
		
		if(args.length < 2) {
			  throw new IllegalArgumentException("Inserisci argomenti validi.");
			}
		
		JSONParser parser = new JSONParser();
		String thisLine;
		boolean trovato = false;
		boolean nome_in_lista = false;
		List<Info> DataList = new ArrayList<Info>();
		List<Map> user_mentions = new ArrayList<Map>();
		Info last_0 = new Info();
   	 	DataList.add(last_0);
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(args[0]));

			
			while ((thisLine = br.readLine()) != null) { 
		         
		    Object obj = parser.parse(thisLine);
		    JSONObject jo = (JSONObject) obj; 
		    Map user = ((Map)jo.get("user"));
			String nome = (String) user.get("name");
			
			
			if(nome.equalsIgnoreCase(args[1])){
				nome_in_lista = true;
				Map entities = ((Map)jo.get("entities")); 
				user_mentions = (List<Map>) entities.get("user_mentions");
				String screen_name = (String) user.get("screen_name");
				
				Iterator<Map.Entry> itr1 = user.entrySet().iterator(); 
				while (itr1.hasNext()) { 
					Map.Entry pair = itr1.next(); 
					 if (pair.getKey().equals("id")) {
						 long extract_id = (long) pair.getValue();
						 
						 for (int i = 1; i < DataList.size(); i++) {
							 if (DataList.get(i).id == extract_id) {
								 
								 DataList.get(i).count_tweet++;
								 DataList.get(i).count_user_mentions += user_mentions.size();
						    	 trovato = true;
						    	 
						     }
						  }
						 
						 if(trovato == false) {
						 
							 Info last = new Info();
							 last.id = extract_id;
							 last.count_tweet = 1;
							 last.screen_name = screen_name;
							 last.nome_user = nome;
							 last.count_user_mentions = user_mentions.size();
							 DataList.add(last);
						 }
					 }
					}	
				}
			}
		}catch (IOException e) {
		       System.err.println("Error: " + e);
		       
	     }
		
		
		if(!nome_in_lista)
			
			System.out.println("Utente non trovato nella lista.");
		
		else {
			
			for (int i = 1; i < DataList.size(); i++) {
				System.out.println("id : " + DataList.get(i).id);
				System.out.println("count tweet : " + DataList.get(i).count_tweet);
				System.out.println("count_user_mentions : " + DataList.get(i).count_user_mentions);
				System.out.println("screen_name : " + DataList.get(i).screen_name);
				System.out.println("name : " + DataList.get(i).nome_user);
				System.out.println("--------");
				System.out.println("--------");

		     	}
		}
     }

}